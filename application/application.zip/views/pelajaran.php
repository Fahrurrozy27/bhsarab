<!--
@Project: Learnify
@Author/Programmer: Syauqi Zaidan Khairan Khalaf
@URL: syauqi.js.org
Author E-mail: Zaidanline67@Gmail.com

@About-Learnify :
Web Edukasi Open Source yang
dibuat oleh Syauqi Zaidan Khairan Khalaf.
Learnify adalah Web edukasi yang dilengkapi video, materi, dan soal ( Coming soon )
yang didesign semenarik dan sesimple mungkin. Learnify dibuat ditujukan agar para siswa
dan guru dapat terus belajar dan mengajar dimana saja dan kapan saja.
-->


<!--================Home Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="pelajaran bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background="">
        </div>
        <div class="container">
            <div class="banner_content text-center">
                <h2>Pelajaran</h2>
                <div class="page_link">
                    <a href="<?=base_url('welcome')?>">Beranda</a>
                    <a href="<?=base_url('welcome/pelajaran')?>">Pelajaran</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Home Banner Area =================-->


<!--================Courses Area =================-->
<section class="courses_area p_120">
    <div class="container">
        <div class="main_title">
            <h2>Pelajaran Yang Tersedia</h2>
            <p>Dibawah ini merupakan mata pelajaran yang tersedia di website Learnify. Tiap kelas mempunyai
                materi yang berbeda namun dengan mata pelajaran yang sama. Oleh karena itu nikmati materi dan selamat
                belajar! tunggu update selanjutnya untuk penambahan mata pelajaran!</p>
        </div>
        <div class="row courses_inner">
            <div class="col-lg-9">
                <div class="grid_inner">
                    <div class="grid_item wd55">
                        <div class="courses_item">
                            <img src="<?=base_url('assets/')?>img/courses/course-1.jpg" alt="">
                            <div class="hover_text">
                                <a class="cat" href="#">Gratis</a>
                                <a href="#">
                                    <h4>Kelas Matematika Gratis</h4>
                                </a>
                                <ul class="list">
                                    <li><a href="#"><i class="lnr lnr-users"></i> 34</a></li>
                                    <li><a href="#"><i class="lnr lnr-bubble"></i> 0</a></li>
                                    <li><a href="#"><i class="lnr lnr-user"></i>Guru Matematika SMKN 1 Ciamis</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="grid_item wd44">
                        <div class="courses_item">
                            <img src="<?=base_url('assets/')?>img/courses/course-2.jpg" alt="">
                            <div class="hover_text">
                                <a class="cat" href="#">Premium</a>
                                <a href="#">
                                    <h4>Bahasa Arab 1</h4>
                                </a>
                                <ul class="list">
                                    <li><a href="#"><i class="lnr lnr-users"></i> 34</a></li>
                                    <li><a href="#"><i class="lnr lnr-bubble"></i> 0</a></li>
                                    <li><a href="#"><i class="lnr lnr-user"></i> Guru IPA SMKN 1 Ciamis</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="grid_item wd44">
                        <div class="courses_item">
                            <img src="<?=base_url('assets/')?>img/courses/course-4.jpg" alt="">
                            <div class="hover_text">
                                <a class="cat" href="#">Premium
                                    <h4>Bahasa Arab 2</h4>
                                </a>
                                <ul class="list">
                                    <li><a href="#"><i class="lnr lnr-users"></i> 34</a></li>
                                    <li><a href="#"><i class="lnr lnr-bubble"></i> 0</a></li>
                                    <li><a href="#"><i class="lnr lnr-user"></i> Guru English SMKN 1 Ciamis</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="grid_item wd55">
                        <div class="courses_item">
                            <img src="<?=base_url('assets/')?>img/courses/course-5.jpg" alt="">
                            <div class="hover_text">
                                <a class="cat" href="#">Gratis</a>
                                <a href="#">
                                    <h4>Bahasa Arab 3</h4>
                                </a>
                                <ul class="list">
                                    <li><a href="#"><i class="lnr lnr-users"></i> 34</a></li>
                                    <li><a href="#"><i class="lnr lnr-bubble"></i> 0</a></li>
                                    <li><a href="#"><i class="lnr lnr-user"></i> Guru Indonesia SMKN 1 Ciamis</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="course_item">
                    <img src="<?=base_url('assets/')?>img/courses/course-3.jpg" alt="">
                    <div class="hover_text">
                        <a class="cat" href="#">Gratis</a>
                        <a href="#">
                            <h4>Kelas Pendidikan Agama Islam Gratis</h4>
                        </a>
                        <ul class="list">
                            <li><a href="#"><i class="lnr lnr-users"></i> 35</a></li>
                            <li><a href="#"><i class="lnr lnr-bubble"></i> 0</a></li>
                            <li><a href="#"><i class="lnr lnr-user"></i> Guru Agama SMKN 1 Ciamis</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Courses Area =================-->